### Test file for testing scheme to use different test levels

## test.scheme <- function()
## {
##     ## Purpose: Level 1 test example
##     ## ----------------------------------------------------------------------
##     ## Arguments:
##     ## ----------------------------------------------------------------------
##     ## Author: David Scott, Date: 22 Jan 2010, 12:27

##     print("Level 1 test in runit.testTestScheme performed")

##     return()
## }


level2test.scheme <- function()
{
    ## Purpose: Level 1 test example
    ## ----------------------------------------------------------------------
    ## Arguments:
    ## ----------------------------------------------------------------------
    ## Author: David Scott, Date: 22 Jan 2010, 12:27

    print("Level 2 test in runit.testTestScheme performed")

    return()
}



