## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
knitr::opts_chunk$set(eval = FALSE)

## ----eval = FALSE-------------------------------------------------------------
# install.packages("DoubleML")

## ----message=FALSE, warning=FALSE---------------------------------------------
# library(DoubleML)

## ----eval = FALSE-------------------------------------------------------------
# remotes::install_github("DoubleML/doubleml-for-r")

## ----message=FALSE, warning=FALSE---------------------------------------------
# library(DoubleML)

