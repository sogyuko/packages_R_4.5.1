| pacman Function | Base Equivalent | Description |
|----------------------|----------------------|----------------|
| `p_cran`  | `available.package`  | List CRAN Package |   
| `p_iscran`  | `%in%` + `available.package`  | Logical Test of CRAN |
| `p_search_any`  | NONE | Search for Package by Author |