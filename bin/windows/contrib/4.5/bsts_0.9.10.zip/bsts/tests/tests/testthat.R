library(testthat)
library(bsts)
library(Boom)

test_check("bsts")
