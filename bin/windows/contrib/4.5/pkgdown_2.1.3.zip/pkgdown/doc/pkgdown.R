## ----eval = FALSE-------------------------------------------------------------
# # Run this once to publish your site regularly
# usethis::use_pkgdown_github_pages()

## ----eval = FALSE-------------------------------------------------------------
# # Run once
# # Remove docs/ from gitignore to ensure it is checked into git.
# usethis::use_pkgdown()
# # Run everytime you want to update your site
# pkgdown::build_site()

