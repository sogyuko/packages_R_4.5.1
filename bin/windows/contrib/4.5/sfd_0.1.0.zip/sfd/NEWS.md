# sfd 0.0.1

* Initial CRAN submission.

# sfd 0.1.0

Added some uniform designs for up to 15 parameters. 
