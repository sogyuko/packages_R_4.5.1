# ggtext 0.1.2

- Maintainer changes to Brenton Wiernik.
- Removed LazyData from package DESCRIPTION to fix CRAN NOTE

# ggtext 0.1.1

- Make sure tests don't fail if vdiffr is missing.

# ggtext 0.1.0

First public release. Provides the two ggplot2 theme elements `element_markdown()` and `element_textbox()` and the two geoms `geom_richtext()` and `geom_textbox()`.
