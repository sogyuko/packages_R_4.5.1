oldDoPar <- doFuture:::.getDoPar()
mdebug <- doFuture:::mdebug
mprint <- doFuture:::mprint
mstr <- doFuture:::mstr
