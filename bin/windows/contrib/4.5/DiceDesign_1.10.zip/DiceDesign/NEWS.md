# DiceDesign 1.9 - 2021-02-10

- New function: faureprimeDesign
- Remove accents (UTF-8 characters) in fcts_optimalLHSDesigns.R
- Set .R and .Rd files to ANSI encoding and Unix end of line
- Add reference Owen A.B. Sobol sequence
- New discrepancy metric (mixture discrepancy) in discrepancyCriteria.R

# DiceDesign 1.8-1 - 2019-07-31

- Modified function: wspDesign
- New functions: scaleDesign, unscaleDesign

# DiceDesign 1.7-5 - 2018-07-30

- New datasets: NOLHdesigns, NOLHDRdesigns
- New functions: nolhDesign, nolhdrDesign, olhDesign, xDRDN
- New references: Cioppa, De Rainville, Nguyen
- lazydata=TRUE

# DiceDesign 1.7 - 2015-06-15

# DiceDesign 1.6 - 2014-05-09

# DiceDesign 1.5 - 2014-05-06

# DiceDesign 1.4 - 2014-01-10

# DiceDesign 1.3 - 2013-04-24

# DiceDesign 1.2 - 2013-02-14

# DiceDesign 1.1 - 2011-09-04

# DiceDesign 1.0 - 2010-02-18
