# one rule parses, another not
#
#

x > 10   # parses
mean(x)  # should not parse




