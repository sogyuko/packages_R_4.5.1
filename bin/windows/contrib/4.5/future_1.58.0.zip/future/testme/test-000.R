#' @tags prologue-cleanup
#' @tags detritus-files

message("Test to clean up any detritus files that might originate from R CMD check running examples")

