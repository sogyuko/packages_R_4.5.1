## Private future functions
.onLoad <- future:::.onLoad
.onAttach <- future:::.onAttach
asIEC <- future:::asIEC
FutureRegistry <- future:::FutureRegistry
gassign <- future:::gassign
get_future <- future:::get_future
geval <- future:::geval
grmall <- future:::grmall
commaq <- future:::commaq
hpaste <- future:::hpaste
importParallel <- future:::importParallel
mdebug <- future:::mdebug
mdebugf <- future:::mdebugf
parseCmdArgs <- future:::parseCmdArgs
requestCore <- future:::requestCore
requestNode <- future:::requestNode
requirePackages <- future:::requirePackages
tweakExpression <- future:::tweakExpression
whichIndex <- future:::whichIndex
isFALSE <- future:::isFALSE
isNA <- future:::isNA
supports_omp_threads <- future:::supports_omp_threads

get_random_seed <- future:::get_random_seed
set_random_seed <- future:::set_random_seed
as_lecyer_cmrg_seed <- future:::as_lecyer_cmrg_seed
is_lecyer_cmrg_seed <- future:::is_lecyer_cmrg_seed
