# lpSolve 5.6.23

* Memory error fix when BLAS polyfills are used (#25).

# lpSolve 5.6.22

* No changes.

# lpSolve 5.6.21

* Added a `NEWS.md` file to track changes to the package.

* lpSolve now compiles on OpenBSD (#21).

