#ifndef SOURCETOOLS_CORE_CORE_H
#define SOURCETOOLS_CORE_CORE_H

#include <sourcetools/core/macros.h>
#include <sourcetools/core/util.h>

#endif /* SOURCETOOLS_CORE_CORE_H */
