# listcomp 0.4.1

* The symbols for the variables of the generated code are not generated using
  a hash function anymore. This greatly reduces memory consumption.

# listcomp 0.4.0

* `gen_list` now has an optional `.env` parameter to provide a custom
  evaluation environment.
* Some minor improvements.

# listcomp 0.3.0

* Parallel iterations are now possible by passing a named list of sequences.

# listcomp 0.2.0

* Initial release
